package assignment;

public class hashcodeEquality {
 public hashcodeEquality(int id, String name) {
		super();
		this.id = id;
		this.name = name;
	}
int id;
 String name;
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public static void main(String[] args) {
	hashcodeEquality check1 =new hashcodeEquality(1,"Sameer");
	hashcodeEquality check2 =new hashcodeEquality(2,"Shrestha");

    System.out.println(" hashcode = " + check1.hashCode());
    System.out.println(" hashcode = " + check2.hashCode());
    System.out.println(" equality = " + check1.equals(check2));
}
}
