package assignment;

/* 
    class Course {
	 public String courseId;
	 public String courseTitle;
	 public String courseInstructor;
	 public Course() {
		 
	 }
	 getCourseInstuctor(){
		 return courseInstructor;
	 }
	 static int noOfInstructors;

}
 */

// We need to provide getter and setter method and make the access 
//specifier of variable as private
// for implementing encapsulation and for refactoring making the
//code more optimize and removing redundancy is important as below.
 
 public class Course {
		private String courseId;
		private String courseTitle;
		private String courseInstructor;
		private static int noOfInstructors;

		public String getCourseId() {
			return courseId;
		}

		public void setCourseId(String courseId) {
			this.courseId = courseId;
		}

		public String getCourseTitle() {
			return courseTitle;
		}

		public void setCourseTitle(String courseTitle) {
			this.courseTitle = courseTitle;
		}

		public String getCourseInstructor() {
			return courseInstructor;
		}

		public void setCourseInstructor(String courseInstructor) {
			this.courseInstructor = courseInstructor;
		}

		public static int getNoOfInstructors() {
			return noOfInstructors;
		}

		public static void setNoOfInstructors(int noOfInstructors) {
			Course.noOfInstructors = noOfInstructors;
		}

	}
