package assignment;
import java.util.Scanner;
public class Addition {
public int add(int[] num) {
	int sum=0;
	for(int i=0;i<num.length;i++) {
		sum+=num[i];
	}
	return sum;
}

//Because of Compilation error,we changed the method name
public String add1(int[] num) {
	String concat="";
	for(int i=0;i<num.length-1;i++) {
		concat=concat+Integer.toString(num[i])+",";
	}
	concat=concat+Integer.toString(num[num.length-1]);
return concat;
	
}
public static void main(String[] args) {
	Addition obj=new Addition();
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter the length");
	int n=sc.nextInt();
	int[] num=new int[n];
	System.out.println("Enter the numbers");
	for(int i=0;i<n;i++) {
		num[i]=sc.nextInt();
	}
	System.out.println("result before creating second method:"+obj.add(num));
	System.out.println("result after creating second method:"+obj.add1(num));
	sc.close();
}
}
