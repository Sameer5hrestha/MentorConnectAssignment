package assignment;

public class Bird {
	//instance variable
	int price;
	float weight;
	double id;
	boolean canFly;
	String name="Peacock";
	
	//Static variable
	static int sprice;
	static float sweight;
	static double sid;
	static boolean scanFly;
	static String sname = "Parrot";

	public void fly() {
		System.out.println("Bird Flew");
	}
}

