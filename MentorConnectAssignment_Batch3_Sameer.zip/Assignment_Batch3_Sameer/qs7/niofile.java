package assignment;
import java.io.IOException;
import java.nio.file.Paths;
import java.util.List;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;


public class niofile {

	public static void main(String[] args) {
		Path assignment = Paths.get("E:\\Batch3.txt");
	      Charset charset = Charset.forName("ISO-8859-1");
	      try {
	         List<String> contains = Files.readAllLines(assignment, charset);
	         for (String word : contains) {
	            System.out.println(word);
	         }
	      } 
	      catch (IOException e) {
	        e.printStackTrace();
	      }

	}

}
