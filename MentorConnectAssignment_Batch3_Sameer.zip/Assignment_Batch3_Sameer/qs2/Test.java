package assignment;

public class Test {
public static Bird first;


public static void main(String[] args) {
	Bird obj=new Bird();
	System.out.println("instance variable of Bird class are:\n"+"price="+obj.price+",weight="+obj.weight+",id="+obj.id+",fly="+obj.canFly+",Bird="+obj.name+"\n");
	System.out.println("static variable of Bird class are:\n"+"price="+Bird.sprice+",weight="+Bird.sweight+",id="+Bird.sid+",fly="+Bird.scanFly+",Bird="+Bird.sname+"\n");
	
	System.out.println("static variable of test class is:\n"+"Bird="+first);

}
}
